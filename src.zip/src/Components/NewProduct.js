
import './NewProduct.css';
import ProductForm from './ProductForm';

function NewProduct(){
    return(
        <div className='new-product'>
            <ProductForm />
        </div>
    )
}

export default NewProduct;